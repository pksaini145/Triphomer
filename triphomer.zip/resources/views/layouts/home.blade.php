@include('header')
@yield('content')
@include('cheapTicket')
@include('footer')
