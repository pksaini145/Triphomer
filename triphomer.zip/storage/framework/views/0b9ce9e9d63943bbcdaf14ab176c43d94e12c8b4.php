<?php $__env->startSection('title','Edit Inner Page'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
                <?php $__errorArgs = ['heading'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="alert-danger"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="alert-danger"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="alert-danger"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <form action="<?php echo e(route('update_inner_page',$pages->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
                    <button type="button" class="btn btn-block as-seo-btn" data-toggle="collapse" data-target="#demo"><i
                            class="fa fa-angle-down"></i> SEO Content</button>
                    <div id="demo" class="collapse as-seo-content-label">
                        <label for="fname" class="mt-4">Meta Title</label>
                        <input type="text" id="meta-title" name="seo_title" value="<?php echo e($pages->seo_title); ?>" class="form-control"><br>
                        <label for="lname">Meta Description</label>
                        <input type="text" id="meta-description" name="seo_desc" value="<?php echo e($pages->seo_desc); ?>" class="form-control"><br>
                        <label for="fname">Meta keywords</label>
                        <input type="text" id="meta-keyboard" name="seo_keywords" value="<?php echo e($pages->seo_keywords); ?>" class="form-control"><br>
                        <label for="fname">Google Plus Title Content</label>
                        <input type="text" id="gptc" name="gp_title" value="<?php echo e($pages->gp_title); ?>" class="form-control"><br>
                        <label for="lname">Google Plus Description Content</label>
                        <input type="text" id="gpdc" name="gp_desc" value="<?php echo e($pages->gp_desc); ?>" class="form-control"><br>
                        <label for="fname">FBTitle Content</label>
                        <input type="text" id="fbtitle-content" name="fb_title" value="<?php echo e($pages->fb_title); ?>" class="form-control"><br>
                        <label for="lname">FBDescription</label>
                        <input type="text" id="fb-description" name="fb_desc" value="<?php echo e($pages->fb_desc); ?>" class="form-control"><br>
                        <div class="row">
                        <div class="col-lg-6">
                        <label for="fname">Page Name(Breadcrumb)</label>
                        <input type="text" id="top-heading" name="heading" class="form-control mb-4" value="<?php echo e($pages->heading); ?>">
                        </div>
                        <div class="col-lg-6">
                        <label for="fname">Url</label>
                        <input type="text" id="top-heading" name="slug" class="form-control mb-4" value="<?php echo e($pages->slug); ?>">
                        </div>
                        </div>
                        
                        <div class="row">                            
                            <div class="col-lg-3">
                                <label class="radio-inline">
                                    Indexable
                                </label>
                                <label class="radio-inline">
                                    <input type="radio" name="index" <?php if($pages->index == 1): ?> checked <?php endif; ?> value="1">Yes
                                </label>
                                <label class="radio-inline">
                                    <input type="radio" name="index" <?php if($pages->index == 0): ?> checked <?php endif; ?> value="0">No
                                </label>
                            </div>
                            <div class="col-lg-3">
                                <label class="radio-inline">
                                    IsActiveDeal
                                </label>
                                <label class="radio-inline">
                                    <input type="radio" name="deal" <?php if($pages->deal == 1): ?> checked <?php endif; ?> value="1">Active
                                </label>
                                <label class="radio-inline">
                                    <input type="radio" name="deal" <?php if($pages->deal == 0): ?> checked <?php endif; ?> value="0">InActive
                                </label>
                            </div>
                            <div class="col-lg-3">
                                <label class="radio-inline">
                                    Status
                                </label>
                                <label class="radio-inline">
                                    <input type="radio" name="status" <?php if($pages->status == 1): ?> checked <?php endif; ?> value="1">Active
                                </label>
                                <label class="radio-inline">
                                    <input type="radio" name="status" <?php if($pages->status == 0): ?> checked <?php endif; ?> value="0">InActive
                                </label>
                            </div>
                        </div>

                        <div class="row mt-4">
                            <div class="col-lg-3">
                                <label class="radio-inline">
                                    Footer Link
                                </label>
                                <label class="radio-inline">
                                    <input type="radio" name="footer_link" <?php if($pages->footer_link == 1): ?> checked <?php endif; ?> value="1">Yes
                                </label>
                                <label class="radio-inline">
                                    <input type="radio" name="footer_link" <?php if($pages->footer_link == 0): ?> checked <?php endif; ?> value="0">No
                                </label>
                            </div>

                            <div class="col-lg-4">
                                <label class="radio-inline">
                                   Flight Category 
                                </label>
                                <label class="radio-inline">
                                    <input type="radio" name="type" <?php if($pages->type == 1): ?> checked <?php endif; ?> value="1">International
                                </label>
                                <label class="radio-inline">
                                    <input type="radio" name="type" <?php if($pages->type == 2): ?> checked <?php endif; ?> value="2">Domestic
                                </label>
                            </div>

                        </div>

                        
                    </div>
                    

                    <button type="button" class="btn btn-block as-seo-btn mt-4" data-toggle="collapse"
                        data-target="#newtemplate"><i class="fa fa-angle-down"></i> New Template Content</button>
                    <div id="newtemplate" class="collapse as-seo-content-label">
                        <div class="row mt-4">
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="exampleFormControlSelect1">Header For Hero</label>
                                    <input type="text" id="header" name="hero_heading" value="<?php echo e($pages->hero_heading); ?>" class="form-control"><br>
                                </div>
                            </div>
                        </div>

                        
                        <label for="lname" >SubContent</label>
                        <textarea class="form-control" rows="2" id="comment"  name="subheading"><?php echo e($pages->subheading); ?></textarea>

                        <div class="container-fluid">
                            <div class="row">
                                <label for="lname" class="mt-4">Content</label>
                                <div class="col-lg-12 nopadding">
                                    <textarea id="txtEditor" name="content"> <?php echo e($pages->content); ?></textarea>
                                </div>
                            </div>
                        </div>




                    </div>
                    <input type="submit" name="submit">
            </form>
                </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u827248895/domains/triphomer.com/public_html/resources/views/dashboard/flights/edit_inner.blade.php ENDPATH**/ ?>