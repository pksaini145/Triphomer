 <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span> &copy; <?php echo e(date('Y')); ?> triphomer.com</span>
                    </div>
                </div>
            </footer><?php /**PATH /home/u827248895/domains/triphomer.com/public_html/resources/views/dashboard/footer.blade.php ENDPATH**/ ?>