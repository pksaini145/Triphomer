<?php $__env->startSection('title','Flight Inner Pages'); ?>

<?php $__env->startSection('content'); ?>
 <!-- Begin Page Content -->

                <div class="container-fluid">
                	<style type="text/css">
 	.headersection h1{
 		display: inline-block !important;
 	}
 	.add-new-flight{
 		float: right;
 	}
 </style>

                    <!-- Page Heading -->
                    <div class="headersection">
                    <h1 class="h3 mb-2 text-gray-800">Flights Inner Pages</h1>
                    <a href="<?php echo e(route('add.inner.pages')); ?>" class="btn btn-info btn-icon-split add-new-flight">
<span class="text">Add New</span>
</a>
</div>
                    
                    <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
                 

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <!-- <h6 class="m-0 font-weight-bold text-primary"></h6> -->
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>PID</th>
                                            <th>Cache</th>
                                            <th>PortalID</th>
                                            <th>URL</th>
                                            <th>DeskTemplate</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                  
                                   <tbody>
                                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <tr>
                                            <td><?php echo e($page->id); ?></td>
                                            <td>Cache</td>
                                            <td>PortalID</td>
                                            <td><?php echo e($page->slug); ?></td>
                                            <td><?php echo e($page->heading); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('edit_inner_page',$page->id)); ?>" class="btn btn-info btn-icon-split">
                                                <span class="text">Edit</span>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       
                                        
                                   </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u827248895/domains/triphomer.com/public_html/newTriphomer/resources/views/dashboard/flights/inner_pages.blade.php ENDPATH**/ ?>