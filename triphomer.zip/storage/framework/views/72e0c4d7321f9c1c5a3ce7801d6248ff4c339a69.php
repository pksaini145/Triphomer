<section class="directory">
    <div class="container">
        <div class="row">
            <div class="col-12 col-sm-6">
                <h4 class="title curve-shape pb-3 mt-4">Find Cheap Tickets by Destination</h4>
                <ul class="directory__list">
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Flights to Fort
                            Myers</a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Flights to
                            Phoenix</a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Flights to
                            Dallas</a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Flights to Ft
                            Lauderdale </a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Flights to San
                            Diego</a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Flights to
                            Chicago</a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Flights to
                            Atlanta</a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Flights to San
                            Francisco</a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Flights to
                            Miami</a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Flights to
                            Denver</a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Flights to San
                            Juan</a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Flights to
                            Orlando</a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Flights to
                            Honolulu</a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Flights to
                            Seattle</a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Flights to Las
                            Vegas</a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Flights to Los
                            Angeles</a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Flights to
                            Tampa</a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Flights to New
                            York</a></li>
                </ul>
            </div>
            <div class="col-12 col-sm-6">
                <h4 class="title curve-shape pb-3 mt-4">Find Cheap Tickets by Airline</h4>
                <ul class="directory__list">
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Philippine
                            Airlines</a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Spirit
                            Airlines</a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Airasia</a>
                    </li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Latam
                            Airlines</a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">American
                            Airlines</a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Emirates
                            Airlines</a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Norwegian
                            Air</a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Qatar
                            Airways</a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Frontier
                            Airlines</a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">United
                            Airlines</a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Air India</a>
                    </li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Volaris</a>
                    </li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Saudia</a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Alaska
                            Airlines</a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Air Canada</a>
                    </li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Caribbean
                            Airlines</a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">Turkish
                            Airlines</a></li>
                    <li class="directory__col-4"><a class="directory__link" target="_blank" href="#">China
                            Airlines</a></li>
                </ul>
            </div>
        </div>
        <hr class="my-4">
    </div>
</section><?php /**PATH C:\Users\hp\Desktop\tripHomer\resources\views/cheapTicket.blade.php ENDPATH**/ ?>