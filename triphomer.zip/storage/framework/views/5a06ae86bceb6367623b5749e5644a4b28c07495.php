<!--  START FOOTER AREA -->
<section class="footer-area section-bg padding-bottom-30px">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-12 ">
                <div class="footer-item">
                    <div class="footer-logo pb-1">
                        <a href="index" class="foot__logo"><img src="assets/img/triphomer-logo.png" alt="logo"
                                class="img-fluid"></a>
                    </div>

                    <p class="footer__desc text-justify" style="font-size:13px;">Trip Homer is the fastest-growing
                        Flight, Hotel, Car rental, and Cruise booking portal with its footprints all around the
                        world.</p>

                </div>

            </div>

            <div class="col-lg-3 col-4 ">
                <div class="footer-item">
                    <h4 class="title curve-shape pb-3 ">About </h4>
                    <ul class="list-items list--items">
                        <li> <a href="#">My Blog</a></li>
                        <li><a href="about.html">About us</a></li>
                        <li><a href="contact.html">Contact us</a></li>
                        <li> <a href="mytrip.html">My Trip</a></li>
                        <li> <a href="login.html">Login </a></li>
                    </ul>
                </div>

            </div>

            <div class="col-lg-3 col-4 ">
                <div class="footer-item">
                    <h4 class="title curve-shape pb-3 ">Legal</h4>
                    <ul class="list-items list--items">
                        <li><a href="terms.html">Terms &amp; Conditions</a></li>
                        <li><a href="policy.html">Privacy Policy</a></li>
                        <li><a href="help.html">Help</a></li>
                        <li><a href="#">Taxes &amp; Fees</a></li>

                        <li><a href="#">Cookie Policy</a></li>

                    </ul>
                </div>

            </div>

            <div class="col-lg-3 col-4 ">
                <div class="footer-item">
                    <h4 class="title curve-shape pb-3 ">Site Directories</h4>
                    <ul class="list-items list--items">
                        <li class="directory__item"><a class="directory__link" target="_blank" href="flight-destination.html">Flight
                                Destinations</a></li>
                        <li class="directory__item"><a class="directory__link" target="_blank" href="hotel-destination.htmls">Hotel
                                Destinations</a></li>
                        <li class="directory__item"><a class="directory__link" target="_blank" href="#">Airports</a>
                        </li>
                        <li class="directory__item"><a class="directory__link" target="_blank" href="airline.html">Airlines</a>
                        </li>
                    </ul>
                </div>

            </div>

        </div>

        <div class="row align-items-center">

            <div class="col-lg-12">
                <div class="footer-social-box text-right">
                    <ul class="social-profile">
                        <li><a href="#"><svg class="svg-inline--fa fa-facebook-f fa-w-10" aria-hidden="true"
                                    focusable="false" data-prefix="fab" data-icon="facebook-f" role="img"
                                    xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" data-fa-i2svg="">
                                    <path fill="currentColor"
                                        d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z">
                                    </path>
                                </svg><!-- <i class="fab fa-facebook-f"></i> --></a></li>
                        <li><a href="#"><svg class="svg-inline--fa fa-twitter fa-w-16" aria-hidden="true"
                                    focusable="false" data-prefix="fab" data-icon="twitter" role="img"
                                    xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg="">
                                    <path fill="currentColor"
                                        d="M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z">
                                    </path>
                                </svg><!-- <i class="fab fa-twitter"></i> --></a></li>
                        <li><a href="#"><svg class="svg-inline--fa fa-instagram fa-w-14" aria-hidden="true"
                                    focusable="false" data-prefix="fab" data-icon="instagram" role="img"
                                    xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" data-fa-i2svg="">
                                    <path fill="currentColor"
                                        d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z">
                                    </path>
                                </svg><!-- <i class="fab fa-instagram"></i> --></a></li>
                        <li><a href="#"><svg class="svg-inline--fa fa-linkedin-in fa-w-14" aria-hidden="true"
                                    focusable="false" data-prefix="fab" data-icon="linkedin-in" role="img"
                                    xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" data-fa-i2svg="">
                                    <path fill="currentColor"
                                        d="M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z">
                                    </path>
                                </svg><!-- <i class="fab fa-linkedin-in"></i> --></a></li>
                    </ul>
                </div>
            </div>

        </div>

    </div>




</section>
<section class="as-payment-icon">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="copy-right-content d-flex align-items-center justify-content-center">
                    <img src="assets/img/master card.png" alt="">
                    <img src="assets/img/visa.png" alt="">
                    <img src="assets/img/AMC.png" alt="">
                    <img src="assets/img/discover.png" alt="">
                    <img src="assets/img/Diners club.png" alt="">
                    <img src="assets/img/PP.png" alt="">
                </div>
            </div>
        </div>
</section>

<section class="as-copyright-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-4">
                <div class="copy-right ">
                    <p class="copy__desc">
                        &copy; <?php echo e(date('Y')); ?> triphomer.com
                </div>
            </div>
            <div class="col-lg-8 as-footer-address">
                <p>
                    <i class="fa fa-map-marker-alt"></i> 10926 Poblado Road, San Diego, CA 92127, USA
                </p>
            </div>
        </div>
    </div>
</section>

<!--  End FOOTER AREA -->

<!-- start back-to-top -->
<div id="back-to-top">
    <i class="fas fa-angle-up" title="Go top"></i>
</div>
<!-- end back-to-top -->

<!-- end modal-shared -->
<div class="modal-popup">
    <div class="modal fade" id="signupPopupForm" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <h5 class="modal-title title" id="exampleModalLongTitle">Sign Up</h5>
                        <p class="font-size-14">Hello! Welcome Create a New Account</p>
                    </div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true" class="fas fa-times"></span>
                    </button>
                </div>
                <div class="modal-body">
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end modal-popup -->

<!-- end modal-shared -->
<div class="modal-popup">
    <div class="modal fade" id="loginPopupForm" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <h5 class="modal-title title" id="exampleModalLongTitle2">Login</h5>
                        <p class="font-size-14">Hello! Welcome to your account</p>
                    </div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true" class="fas fa-times"></span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="contact-form-action">
                        <form method="post">
                            <div class="input-box">
                                <label class="label-text">Username</label>
                                <div class="form-group">
                                    <span class="fa fa-user form-icon"></span>
                                    <input class="form-control" type="text" name="text"
                                        placeholder="Type your username">
                                </div>
                            </div>
                            <!-- end input-box -->
                            <div class="input-box">
                                <label class="label-text">Password</label>
                                <div class="form-group mb-2">
                                    <span class="fa fa-lock form-icon"></span>
                                    <input class="form-control" type="text" name="text"
                                        placeholder="Type your password">
                                </div>
                                <div class="d-flex align-items-center justify-content-between">
                                    <div class="custom-checkbox mb-0">
                                        <input type="checkbox" id="rememberchb">
                                        <label for="rememberchb">Remember me</label>
                                    </div>
                                    <p class="forgot-password">
                                        <a href="recover.php">Forgot Password?</a>
                                    </p>
                                </div>
                            </div>
                            <!-- end input-box -->
                            <div class="btn-box pt-3 pb-4">
                                <button type="button" class="theme-btn w-100">Login Account</button>
                            </div>
                            <div class="action-box text-center">
                                <p class="font-size-14">Or Login Using</p>
                                <ul class="social-profile py-3">
                                    <li><a href="#" class="bg-5 text-white"><i class="fab fa-facebook-f"></i></a>
                                    </li>
                                    <li><a href="#" class="bg-6 text-white"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#" class="bg-7 text-white"><i class="fab fa-instagram"></i></a>
                                    </li>
                                    <li><a href="#" class="bg-5 text-white"><i class="fab fa-linkedin-in"></i></a>
                                    </li>
                                </ul>
                            </div>
                        </form>
                    </div>
                    <!-- end contact-form-action -->
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end modal-popup -->


<!-- Template JS Files -->
<script src="<?php echo e(asset('/assets/js/jquery-3.4.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/js/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/js/bootstrap-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/js/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/js/daterangepicker.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/js/jquery.fancybox.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/js/jquery.countTo.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/js/animated-headline.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/js/jquery.ripples-min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/js/quantity-input.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/js/fontawesome.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/js/main.js')); ?>"></script>

</body>

</html><?php /**PATH C:\Users\hp\Desktop\tripHomer\resources\views/footer.blade.php ENDPATH**/ ?>