<?php $__env->startSection('title','Sitemap'); ?>

<?php $__env->startSection('content'); ?>
<!--  Sitemap Start -->
    <section class="st_map">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="site_map_bx">
                        <h2>Site Map</h2>
                        <p>We do offer latest flight fares to all major destinations across the globe.Here is the full
                            list of all major destinations &amp; quick links to access this website.</p>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="site_cat">
                        <h3>Quick Links</h3>
                        <ul>
                            <li> <a href="<?php echo e(route('home')); ?>"> <img src="<?php echo e(asset('/assets/img/dynamic-li-arrow.png')); ?>"> Home </a></li>
                            <li> <a href="<?php echo e(route('flights')); ?>"> <img src="<?php echo e(asset('/assets/img/dynamic-li-arrow.png')); ?>"> Flights </a></li>
                            <li> <a href="<?php echo e(route('hotels')); ?>"> <img src="<?php echo e(asset('/assets/img/dynamic-li-arrow.png')); ?>"> Hotels </a></li>
                            <li> <a href="<?php echo e(route('cars')); ?>"> <img src="<?php echo e(asset('/assets/img/dynamic-li-arrow.png')); ?>"> Cars </a></li>
                            <li> <a href="<?php echo e(route('airlines')); ?>"> <img src="<?php echo e(asset('/assets/img/dynamic-li-arrow.png')); ?>"> Airlines </a></li>
                            <li> <a href="<?php echo e(route('about')); ?>"> <img src="<?php echo e(asset('/assets/img/dynamic-li-arrow.png')); ?>"> About us </a></li>
                            <li> <a href="<?php echo e(route('contact')); ?>"> <img src="<?php echo e(asset('/assets/img/dynamic-li-arrow.png')); ?>"> Contact us </a></li>
                            <li> <a href="#"> <img src="<?php echo e(asset('/assets/img/dynamic-li-arrow.png')); ?>"> Blogs </a></li>
                            
                            

                            <li> <a href="<?php echo e(route('privacy')); ?>"> <img src="<?php echo e(asset('/assets/img/dynamic-li-arrow.png')); ?>"> Privacy policy </a>
                            </li>
                            <li> <a href="<?php echo e(route('terms')); ?>"> <img src="<?php echo e(asset('/assets/img/dynamic-li-arrow.png')); ?>"> Terms and Services
                                </a></li>
                                <li> <a href="<?php echo e(route('help')); ?>"> <img src="<?php echo e(asset('/assets/img/dynamic-li-arrow.png')); ?>"> Help
                                </a></li>
                            <!-- <li> <a href="freeCancellation.html"> <img src="assets/img/dynamic-li-arrow.png"> Refund
                                    &amp; Cancellation Policy </a></li> -->
                            

                        </ul>
                    </div>
                    <div class="site_cat">
                        <h3>Domestic Destinations</h3>
                        <ul>

                           <!--  <li> <a href="# "> <img
                                        src="assets/img/dynamic-li-arrow.png"> Alaska Flights </a></li> -->

                                        <?php if(isset($flight_destinations2)): ?>
                     <?php $__currentLoopData = $flight_destinations2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flight2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li ><a  href="<?php echo e(route('flights', $flight2->slug)); ?>"><img
                                        src="<?php echo e(asset('/assets/img/dynamic-li-arrow.png')); ?>"><?php echo e($flight2->heading); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                            
                        </ul>
                    </div>

                    <div class="site_cat">
                        <h3>International Destinations</h3>
                        <ul>


                           <!--  <li> <a href="https://skyhikes.com/International/flight-to-Madrid"> <img
                                        src="assets/img/dynamic-li-arrow.png"> Madrid Flights</a></li> -->

                            <?php if(isset($flight_destinations)): ?>
                     <?php $__currentLoopData = $flight_destinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flightl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li ><a href="<?php echo e(route('flights', $flightl->slug)); ?>"><img
                                        src="<?php echo e(asset('/assets/img/dynamic-li-arrow.png')); ?>"><?php echo e($flightl->heading); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                        </ul>
                    </div>

                    <!-- <div class="site_cat">
                        <h3>Major Airlines</h3>
                        <ul>


                            <li> <a href="https://skyhikes.com/airlines/Aeromexico"> <img
                                        src="assets/img/dynamic-li-arrow.png"> Aeromexico </a> </li>

                        </ul>
                    </div> -->
                </div>
            </div>
        </div>
    </section>

    <!-- Sitemap end -->
    <style type="text/css">
    	.cheap_ticket,section.footer-area.section-bg.padding-bottom-30px,section.as-payment-icon{
    		display: none;
    	}
    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u827248895/domains/triphomer.com/public_html/resources/views/sitemap.blade.php ENDPATH**/ ?>